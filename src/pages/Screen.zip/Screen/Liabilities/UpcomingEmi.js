import React from 'react'
import {  CardBody } from 'reactstrap';

export const UpcomingEmi = () => {



  return (
    <React.Fragment>
    <CardBody>
    <div>UpcomingEmi</div>
<div style={{display:"flex" , gap:"180px"}}>
  <h4>Home Loan</h4>
  <span>&#8377;5,286.03</span>
</div>

    </CardBody>
    </React.Fragment>
  )
}
